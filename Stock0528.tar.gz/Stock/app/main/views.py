from . import main
from flask import redirect, request, session

@main.before_app_request
def process_request(*args, **kwargs):
    if request.path[:7] == '/static':
        return None
    if request.method == 'POST':
        # print('POST request'7
        return None
    if request.path == '/init' or request.path == '/crawler/init':
        print("初始化时跳过登录检测")
        return None
    if request.path == '/market/login':  # 白名单路由'/market/login'
        # print('/market/login')
        return None
    if session.get('username'):   # session中记录了登录状态
        return None
    # print('redirect', request.path)
    return redirect('/market/login')     # 重定向至登录页

# 尝试写全局的404页面，失败，原因未知
# @main.errorhandler
# def page_not_found(error):
#     return '页面未找到', 404

@main.route('/')
def index():
    return redirect('/market')

@main.route('/init')
def init():
    return redirect('/crawler/init')


@main.before_app_first_request
def process_request(*args, **kwargs):
    from ..models import StockCode
    from ..crawler.views import updateRealtimeByStock
    from time import sleep, time
    import os
    import signal
    # print('Hello World!')

    # 对数据库进行初始化
    from ..crawler.views import init_stock
    init_stock()

    # 循环更新实时数据
    print('**************开始实时更新**************')
    pid = os.fork()
    if pid < 0:
        print('创建子进程失败')
    elif pid == 0:
        # 创建二级子进程
        pid0 = os.fork()
        if pid0 < 0:
            print('创建二级子进程失败')
        elif pid0 == 0:
            # 顺便将所有的50股数据更新一遍
            print('开始循环作业')
            try:
                while True:
                    t = time()
                    stocks = StockCode.query.all()
                    # print(stocks)
                    for stock in stocks:
                        # print('init:', stock)
                        updateRealtimeByStock(stock)
                    print('实时信息更新完毕, 耗时{}秒'.format(time()-t))
            except Exception as ex:
                print(ex)
            finally:
                print('结束作业')
                os._exit(0)
        else:
            os._exit(0)
    else:
        os.wait()
        # os._exit(0)
        return None