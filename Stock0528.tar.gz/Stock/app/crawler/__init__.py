from flask import Blueprint
crawler = Blueprint('crawler', __name__, url_prefix='/crawler')

from . import views