import baostock as bs
import pandas as pd
# from functools import wraps

'参考网址: http://baostock.com/baostock/index.php'
 

# def baostock_login_N_out(func):
#     @wraps(func)
#     def wrapLoginNOut(*args, **kwargs):
#         lg = bs.login()
#         # print('login respond error_code:' + lg.error_code)
#         # print('login respond  error_msg:' + lg.error_msg)
#         func(*args, **kwargs)
#         bs.logout()
#     return wrapLoginNOut

def get_sz50_index():
    """
    获得上证50指数
    return: 一维列表
    """
    rs = bs.query_stock_basic(code="sh.000016")
    # print('query_sz50 error_code:' + rs.error_code)
    # print('query_sz50  error_msg:' + rs.error_msg)
    data_list = rs.get_row_data()
    return data_list[:2]

def get_sz50_stocks():
    """
    获得最新上证50成分股名单
    :return: 二维列表数据   # 过期:DataFrame类型的上证50成分股名单
    """
    rs = bs.query_sz50_stocks()
    # print('query_sz50 error_code:' + rs.error_code)
    # print('query_sz50  error_msg:' + rs.error_msg)

    sz50_stocks = []
    while (rs.error_code == '0') & rs.next():
        sz50_stocks.append(rs.get_row_data())
    # return pd.DataFrame(sz50_stocks, columns=rs.fields)
    return sz50_stocks

def query_history_k_data(code, fields, start, end, frequency, adjustflag):
    """
    查询某支股票的历史K线数据
    :param code: 股票代码, 例'sh.600000'
    :param fields: 指示简称, 根据fields返回对应的数据
    :param start: 开始日期, 例'2017-07-01'
    :param end: 结束日期, 例'2017-12-31'
    :param frequency:
        K线类型, 默认'd'为日线,'w','m','5','15','30','60'
    :param adjustflag: 复权因子, 默认不复权:'3'; 后复权:'1'; 前复权:'2'
    :return: 二维列表数据   # 过期:DataFrame类型的数据
    """
    rs = bs.query_history_k_data_plus(
        code, fields, start_date=start, end_date=end,
        frequency=frequency, adjustflag=adjustflag
    )
    # print('query_history_k_data_plus respond error_code:' + rs.error_code)
    # print('query_history_k_data_plus respond  error_msg:' + rs.error_msg)
    data_list = []
    while (rs.error_code == '0') & rs.next():
        data_list.append(rs.get_row_data())
    # return pd.DataFrame(data_list, columns=rs.fields)
    return data_list

if __name__ == '__main__':
    lg = bs.login()
    # print('login respond error_code:' + lg.error_code)
    # print('login respond  error_msg:' + lg.error_msg)

    # print(get_sz50_index())

    # print(get_sz50_stocks())

    # get_sz50_stocks().to_csv('sz50_stocks.csv', encoding='utf-8', index=False)
  
  
    # sz50 = pd.read_csv('sz50_stocks.csv')
    frames = []
    fields = 'date,code,open,high,low,close,preclose,volume,amount,adjustflag,turn,tradestatus,pctChg'
    start = '2019-1-2'
    end = '2019-1-3'
    frequency = 'd'
    adjustflag = '3'
    code = 'sh.600000'
    # for code in sz50['code']:
    #     data = query_history_k_data(code, fields, start, end, frequency, adjustflag)
    #     frames.append(data)
    # print(pd.concat(frames))
    print(query_history_k_data(code, fields, start, end, frequency, adjustflag))

    bs.logout()