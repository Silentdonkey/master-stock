from . import crawler
from flask import request
import requests
import json
from ..models import StockCode, StockRealtime
from datetime import datetime
from .. import db
import os

def getTecentRealtimeStock(code):
    url_format = 'http://qt.gtimg.cn/q={}'
    # url_format = 'http://hq.sinajs.cn/list={}'

    response = requests.get(url_format.format(code))
    return response.text.split('~')   
    # return response.text.split(',')

def float_or_zero(string):
    return float(string) if string else 0.0

def updateRealtimeByStock(stock):
    # try:
    #     realtime = stock.stock_realtime 
    #     exists = True
    # except Exception as ex:
    #     realtime = None
    realtime = StockRealtime.query.filter(StockRealtime.stock_id==stock.id).all()
    exists = True
    if not realtime:
        exists = False
        realtime = StockRealtime()
        realtime.stock_id = stock.id
    else:
        realtime = realtime[0]

    data = getTecentRealtimeStock(stock.code)

    # print(data)
    
    realtime.price = float_or_zero(data[3])
    realtime.pre_close = float_or_zero(data[4])
    realtime.open = float_or_zero(data[5])
    realtime.sell = float_or_zero(data[7])  # 内盘
    realtime.buy = float_or_zero(data[8])  # 外盘
    realtime.buy1 = float_or_zero(data[9])  # 买一
    realtime.buy1_vol = float_or_zero(data[10])  # 买一量
    realtime.buy2 = float_or_zero(data[11])
    realtime.buy2_vol = float_or_zero(data[12])
    realtime.buy3 = float_or_zero(data[13])
    realtime.buy3_vol = float_or_zero(data[14])
    realtime.buy4 = float_or_zero(data[15])
    realtime.buy4_vol = float_or_zero(data[16])
    realtime.buy5 = float_or_zero(data[17])
    realtime.buy5_vol = float_or_zero(data[18])
    realtime.sell1 = float_or_zero(data[19])
    realtime.sell1_vol = float_or_zero(data[20])
    realtime.sell2 = float_or_zero(data[21])
    realtime.sell2_vol = float_or_zero(data[22])
    realtime.sell3 = float_or_zero(data[23])
    realtime.sell3_vol = float_or_zero(data[24])
    realtime.sell4 = float_or_zero(data[25])
    realtime.sell4_vol = float_or_zero(data[26])
    realtime.sell5 = float_or_zero(data[27])
    realtime.sell5_vol = float_or_zero(data[28])
    # realtime.recent_exchange = data[29]
    realtime.time = data[30]
    realtime.change = float_or_zero(data[31])  # 涨跌额
    realtime.change_pct = float_or_zero(data[32])  # 涨跌%
    realtime.high = float_or_zero(data[33])
    realtime.low = float_or_zero(data[34])
    realtime.volumn = float_or_zero(data[36])  # 成交量
    realtime.amount = float_or_zero(data[37])  # 成交额
    # print(data[38])
    realtime.turnover_rate = float_or_zero(data[38])  # 换手率
    realtime.amp = float_or_zero(data[43])  # 振幅
    realtime.circ_mv = float_or_zero(data[44])  # 流通市值
    realtime.total_mv = float_or_zero(data[45])  # 总市值
    realtime.top = float_or_zero(data[47])
    realtime.bottom = float_or_zero(data[48])
    realtime.lb = float_or_zero(data[49])
    realtime.price_avg = float_or_zero(data[51])
    realtime.pe = float_or_zero(data[52])  # 市盈率
    realtime.pb = float_or_zero(data[56])  # 市净率

    if not exists:
        # print('添加新的实时信息条目：', stock.stockname)
        db.session.add(realtime)
    else:
        # print('更新实时信息：', stock.stockname)
        pass
    db.session.commit()

@crawler.route('/init')
def init_stock():
    """
    初始化上证50成分股列表, 初始化用户列表, 初始化用户选股
    """
    from .functions import get_sz50_stocks, get_sz50_index
    import baostock as bs
    from ..models import StockCode, UserStocks, User
    from .. import db
    print('***************开始初始化***************')

    ##################################################
    lg = bs.login()

    # 进行股票列表的初始化
    try:
        # 初始化上证50指数
        code, stockname = get_sz50_index()
        code = code[:2] + code[3:]
        stock = StockCode.query.filter(StockCode.code==code).all()
        # print(stock)
        if not stock:
            stock = StockCode()
            stock.code = code
            stock.stockname = stockname
            db.session.add(stock)
            print('添加上证50指数')

        # 初始化成分股
        for row in get_sz50_stocks():
            # print(row)
            code, stockname = row[1:]
            code = code[:2] + code[3:]
            # print(code , stockname)
            stock = StockCode.query.filter(StockCode.code==code).all()
            # print(stock)
            if not stock:
                stock = StockCode()
                stock.code = code
                stock.stockname = stockname
                db.session.add(stock)
                print('添加股票：', stock.stockname)
    except Exception as ex:
        # print(ex)
        pass

    bs.logout()

    ##################################################
    try: 
        username = 'admin'
        password = 'admin'
        user = User.query.filter(User.username==username).all()
        if not user:
            user = User()
            user.username = username
            user.password = password
            db.session.add(user)
            print('添加用户：', user.username)
    except Exception as ex:
        print('用户{}已存在.'.format('admin'))

    try:
        username = 'Karl'
        password = '123456'
        user = User.query.filter(User.username==username).all()
        if not user:
            user = User()
            user.username = username
            user.password = password
            db.session.add(user)  
            print('添加用户：', user.username)
    except Exception as ex:
        print('用户{}已存在.'.format('Karl'))

    db.session.commit()
    print('***************初始化结束***************')
    return 'ok'



# 更新股票的实时交易数据
@crawler.route('/realtime')
def realtime():
    code = request.args.get('code')
    if not code:    # 当请求中不包含股票代码时， 设定股票代码默认值
        code = 'sh000016'  # 上证50指数

    # 获得返回数据
    # url_format = 'http://qt.gtimg.cn/q={}'
    # response = requests.get(url_format.format(code))
    # result = response.text.split('~')
    result = getTecentRealtimeStock(code)

    # # 创建二级子进程用于更新所有股票的实时数据
    # pid = os.fork()
    # if pid < 0:
    #     print('创建子进程失败')
    # elif pid == 0:
    #     # 创建二级子进程
    #     pid0 = os.fork()
    #     if pid0 < 0:
    #         print('创建二级子进程失败')
    #     elif pid0 == 0:
    #         # 顺便将所有的50股数据更新一遍
    #         try:
    #             stocks = StockCode.query.all()
    #             for stock in stocks:
    #                 updateRealtimeByStock(stock)
    #             print('实时信息更新完毕')
    #         except Exception as ex:
    #             print(ex)
    #         finally:
    #             os._exit(0)
    #     else:
    #         os._exit(0)
    # else:
    #     os.wait()

    #     # print(result)
    #     # 父进程正常返回结果
    #     return json.dumps(result)

    return  json.dumps(result)