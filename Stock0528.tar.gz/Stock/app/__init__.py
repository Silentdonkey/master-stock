from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from .config import *

db = SQLAlchemy()

def create_app():
    app = Flask(__name__, static_folder='static', template_folder='templates')

    app.config['DEBUG'] = IF_DEBUG  # 默认True
    app.config['SQLALCHEMY_DATABASE_URI'] = DB_URI
    app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = IF_TRACK  # 默认False
    app.config['SECRET_KEY'] = SECRET_KEY

    db.init_app(app)

    from .market import market as market_blueprint
    app.register_blueprint(market_blueprint)

    from .crawler import crawler as crawler_blueprint
    app.register_blueprint(crawler_blueprint)

    from .account import account as account_blueprint
    app.register_blueprint(account_blueprint)

    from .main import main as main_blueprint
    app.register_blueprint(main_blueprint)

    return app