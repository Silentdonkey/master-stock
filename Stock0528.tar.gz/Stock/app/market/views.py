import json

from flask import render_template, request, session, redirect
from . import market
from ..models import User, StockCode, UserStocks, StockRealtime
from .. import db
from ..config import RANKING_LIMIT
from sqlalchemy import or_


# 注册路由‘register’
@market.route('/register')
def register():
    return render_template('注册页面(待替换).html')


# 登录路由'login'
@market.route('/login')
def login():
    return render_template('登录页面.html')


# 主页的路由还是改为'/'方便js中设置路由跳转
@market.route('/')
def market_view():
    # print(session.get('username'))

    # # 将数据库中stock信息传递过去
    # stocks = StockCode.query.all()
    # # 导成json格式
    # list = []
    # for stock in stocks:
    #     list.append(stock.to_dict())
    # stocks = json.dumps(list)

    # 检测get请求中是否携带code变量，是，则渲染到网页，否，则设定为默认值
    code = request.args.get('code')
    if not code:
        code = 'sh000016'
    return render_template('market.html', params=locals())


@market.route('/post_news/<index>')
def post_news(index):
    return render_template('post_news%s.html' % (index))

# 用于提供主页左侧栏的股票排行
@market.route('/ranking/<option>')
def ranking(option):
    if option=='1':  # 总市值
        stocks = StockRealtime.query.order_by(db.desc(StockRealtime.total_mv)).limit(RANKING_LIMIT).all()
        ranking = []
        for stock in stocks:
            ranking.append((stock.stock.code, stock.stock.stockname, str(stock.total_mv)+"亿"))
        return json.dumps(ranking)
    elif option=='2':  # 流通市值
        stocks = StockRealtime.query.order_by(db.desc(StockRealtime.circ_mv)).limit(RANKING_LIMIT).all()
        ranking = []
        for stock in stocks:
            ranking.append((stock.stock.code, stock.stock.stockname, str(stock.circ_mv)+"亿"))
        return json.dumps(ranking)    
    elif option=='3':  # 市盈率
        stocks = StockRealtime.query.order_by(db.desc(StockRealtime.pe)).limit(RANKING_LIMIT).all()
        ranking = []
        for stock in stocks:
            ranking.append((stock.stock.code, stock.stock.stockname, str(stock.pe)))
        return json.dumps(ranking)    
    elif option=='4':  # 市净率
        stocks = StockRealtime.query.order_by(db.desc(StockRealtime.pb)).limit(RANKING_LIMIT).all()
        ranking = []
        for stock in stocks:
            ranking.append((stock.stock.code, stock.stock.stockname, str(stock.pb)))
        return json.dumps(ranking)    
    else:
        return json.dumps("")

# 模拟炒股页面(第三张海报，我的账户，模拟炒股暂时都链接到此页面)
@market.route('/simulate')
def simulate():
    return render_template('模拟炒股.html')


# 搜索栏异步刷新来显示并切换股票
@market.route('/search_ajax')
def search_ajax():
    # 接收前端传递过来的kw的值,再进行查询对应的stock们
    kw = request.args['kw']
    print('关键字为:', kw)
    stocks = StockCode.query.filter(
        or_(
            StockCode.stockname.like('%' + kw + '%'),
            StockCode.code.like('%' + kw + '%')
        )
    )
    stocks = stocks.limit(5)  # 限制只显示5条数据
    print('查询结果为', stocks)
    # 导成json格式
    list = []
    for stock in stocks:
        list.append(stock.to_dict())
    print(list)
    jsonStr = json.dumps(list)
    print('查询结果', jsonStr)
    return jsonStr
