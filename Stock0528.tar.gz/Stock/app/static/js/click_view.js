$(function (){
    //以上是初始化值 当选定默认值为1w时
    var value = $('.buy').html();
    var num = value.indexOf(" ");
    var pp = Number(value.substring(0,num));
    //综合交易费用设置
    var str = (pp*10000*0.0045).toFixed(1)
    $('.mt23>span').html(str+'&nbsp;&nbsp;元')

    //自选金额：对应修改其他金额选项
    $('.buy1').children().click(function(){
        var z = $(this).html();
        //不能直接取，含有字符
        //对交易综合费用的计算关联
        var num = z.indexOf(" ");
        var pp = Number(z.substring(0,num));
        var str1 = (pp*10000*0.0045).toFixed(1)
        $('.mt23>span').html(str1+'&nbsp;&nbsp;元')

        //对触发止损的计算关联
        var c = $(this).html();
        var num = c.indexOf(" ");
        var pp = Number(c.substring(0,num));
        var str2 = (pp*10000*0.18).toFixed(1)
        $('.mt24>span').html('-'+str2+'&nbsp;&nbsp;元')

        //对递延条件履约金的缴纳
        var c = $(this).html();
        var num = c.indexOf(" ");
        var pp = Number(c.substring(0,num));
        var str3 = (pp*10000*0.06).toFixed(1)
        $('.mt25>span').html('履约保证金金额&gt;'+str3+'&nbsp;&nbsp;元')

        //对购买股票数量的计算
        var l = $(this).html();
        var num = l.indexOf(" ");
        var pp = Number(l.substring(0,num));
        var bili = Number($('.d-bili').html())
        var str4 = ((pp*10000-str1-str3)/bili).toFixed(0)
        $('.buy-gu').html(str4+'&nbsp;&nbsp;股')

        //资金利用率计算
        var f = $(this).html();
        var num = f.indexOf(" ");
        var pp = Number(f.substring(0,num));
        if(pp==0.2){
            var str6=(pp*10000)/bili.toFixed(2)
            var str5 = ((pp*0.92*10000-str1-str3)/bili).toFixed(2)
            var str7 = (str5/str6*100).toFixed(3)
            $('.buy-size').html(str7+'&nbsp;%')
        }else if(pp==0.5){
            var str6=(pp*10000)/bili.toFixed(2)
            var str5 = ((pp*0.93*10000-str1-str3)/bili).toFixed(2)
            var str7 = (str5/str6*100).toFixed(3)
            $('.buy-size').html(str7+'&nbsp;%')
        }else if(pp==1){
            var str6=(pp*10000)/bili.toFixed(2)
            var str5 = ((pp*0.96*10000-str1-str3)/bili).toFixed(2)
            var str7 = (str5/str6*100).toFixed(3)
            $('.buy-size').html(str7+'&nbsp;%')
        }else if(pp==2){
            var str6=(pp*10000)/bili.toFixed(2)
            var str5 = ((pp*0.99*10000-str1-str3)/bili).toFixed(2)
            var str7 = (str5/str6*100).toFixed(3)
            $('.buy-size').html(str7+'&nbsp;%')
        }else if(pp==3){
            var str6=(pp*10000)/bili.toFixed(2)
            var str5 = ((pp*10000-str1-str3)/bili).toFixed(2)
            var str7 = (str5/str6*100).toFixed(3)
            $('.buy-size').html(str7+'&nbsp;%')
        }else if(pp==5){
            var str6=(pp*10000)/bili.toFixed(2)
            var str5 = ((pp*1.01*10000-str1-str3)/bili).toFixed(2)
            var str7 = (str5/str6*100).toFixed(3)
            $('.buy-size').html(str7+'&nbsp;%')
        }else if(pp==10){
            var str6=(pp*10000)/bili.toFixed(2)
            var str5 = ((pp*1.05*10000-str1-str3)/bili).toFixed(2)
            var str7 = (str5/str6*100).toFixed(3)
            $('.buy-size').html(str7+'&nbsp;%')
        }else if(pp==20){
            var str6=(pp*10000)/bili.toFixed(2)
            var str5 = ((pp*1.06*10000-str1-str3)/bili).toFixed(2)
            var str7 = (str5/str6*100).toFixed(3)
            $('.buy-size').html(str7+'&nbsp;%')
        }


    //显示
//    $(".total-num").html(str);
    })

//    $(".total-num").html(pp);
})

