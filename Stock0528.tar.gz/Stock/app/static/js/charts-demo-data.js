// 分时数据
var mdata = {
    "data": []
};


function getmData(callback) { //分时图
    var stock_code = $("#stock-code").attr("code");
    console.log('1' + stock_code + typeof stock_code);
    $.ajax({
        // url: "http://data.gtimg.cn/flashdata/hushen/minute/sz000001.js?maxage=110&0.28163905744440854",
        url: "http://data.gtimg.cn/flashdata/hushen/minute/" + stock_code + ".js?maxage=110&0.28163905744440854",
        dataType: "script",
        cache: "false",
        type: "GET",
        success: function () {
            // 目前分时图数据缺少均价
            var msg = min_data;
            var result = msg.replace(/\n/g, ",").split(',');
            var arr = result.slice(2, result.length - 1), //开头结尾各一个空数组要去掉
                _arr = [];
            for (var i = 0; i < arr.length; i++) {
                var _a = arr[i].split(" "), _b = arr[i].split(" "), _c = [];
                if (i > 0) {
                    _c = arr[i - 1].split(" ");
                }
                // 腾讯股票接口传的数值0930（日期） 5.55（成交价） 37673（累计成交量，初始成交量为9:30的）
                // 因此每分钟的 成交量 = 当前累计成交量 - 前一分钟的累计成交量
                _b[2] = _c.length > 0 ? _a[2] - _c[2] : _a[2];
                _arr.push(_b)
            }
            mdata.data = _arr;
            callback(mdata)
        },
        error: function () {
            alert("wrong");
        }
    });
}

function getInfo(callback) { //获取股票信息
    var stock_code = $("#stock-code").attr("code");
    console.log('2' + stock_code);
    $.ajax({
        // url: "http://hq.sinajs.cn/list=sz000001",
        url: "http://hq.sinajs.cn/list=" + stock_code,
        // dataType: "script",
        dataType: "script",
        cache: "false",
        // type: "GET",
        type: "get",
        success: function () {
            // var info = hq_str_sh601318;
            //注意此处hq_str_sh601318为变量名，需要拼接变量串！！！
            function format(a, b) {
                return eval(a + b);
            }
            var info = format('hq_str_', stock_code);
            var _info_arr = info.split(",");
            callback(_info_arr);
            // console.log(info)
        },
        error: function () {
            alert("查询信息失败")
        }
    })
}
