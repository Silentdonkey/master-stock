# 数据库相关参数
DB_USER = 'root'
DB_PWD = '123456'
DB_HOST = '127.0.0.1'
DB_PORT = 3306
DB_DBNAME = 'stock_demo'

DB_URI = 'mysql+pymysql://{}:{}@{}:{}/{}?charset=utf8'.format(
            DB_USER, DB_PWD, DB_HOST, DB_PORT, DB_DBNAME
        )

# 股票相关表名
STOCK_LIST = 'stock_list'

RANKING_LIMIT = 10

# Debug模式开关
IF_DEBUG = True
# SQLALCHEMY_TRACK_MODIFICATIONS模式开关
IF_TRACK = True

# 密钥
SECRET_KEY = 'FuckAllofYou'