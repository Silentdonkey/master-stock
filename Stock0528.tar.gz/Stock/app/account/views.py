from flask import render_template, request, session
from . import account
from .. import db
from ..models import User, UserStocks, StockCode


@account.route('/login-check', methods=['GET', 'POST'])
def login_check():
    print('login check?')
    if request.method=='POST':
        username = request.form.get('uname')
        print(username, request.form.get('upwd'))
        user = User.query.filter_by(username=username).first()
        if user.password != request.form.get('upwd'):
            return '0'
        else: 
            session['username'] = username
            return '1'
    else:
        print('fuck you')
        return '0'

# # 测试用路由，测试三表联查，已失效
# @account.route('/test')
# def test():
#     result = db.session.query(User, UserStocks, StockCode).filter(
#         User.id == UserStocks.user_id, UserStocks.stock_id == StockCode.id
#     ).all()
#     # result的数据结构:[(<User 2>, <UserStocks 1>, <StockCode 2>), ...]
#     # for data in result:
#     #     print(data[0].username, data[2].stockname, data[1].amount)

#     return render_template('test.html', data=result)
#     # return 'ok'