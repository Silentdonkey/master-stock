from . import db


class UserStocks(db.Model):
    __tablename__ = 'user_stocks'
    u2s_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    stock_id = db.Column(db.Integer, db.ForeignKey('stock_list.id'))


class StockCode(db.Model):
    __tablename__ = 'stock_list'
    id = db.Column(db.Integer, primary_key=True, default=0)
    # updateDate = db.Column(db.String(16), nullable=False)
    code = db.Column(db.String(16), unique=True, nullable=False)
    stockname = db.Column(db.String(64), nullable=False)
    u2s_list = db.relationship('UserStocks', backref='stock', lazy='dynamic')
    stock_realtime = db.relationship('StockRealtime', backref='stock', lazy='dynamic')

    def __str__(self):
        return '<Stock:{}, {}>'.format(self.stockname, self.code)

    def __repr__(self):
        return self.__str__()

    def to_dict(self):
        dic = {
            'id': self.id,
            'code': self.code,
            'stockname': self.stockname
        }
        return dic


class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(32), unique=True, nullable=False)
    password = db.Column(db.String(32), nullable=False)
    count = db.Column(db.Integer, default=0, nullable=False)
    amount = db.Column(db.Float, default=0, nullable=False)  # 账户余额

    u2s_list = db.relationship('UserStocks', backref='user', lazy='dynamic')

    def __str__(self):
        return 'User:{}, {}'.format(self.id, self.username)

    def to_dict(self):
        dic = {
            'id': self.id,
            'username': self.username,
            'password': self.password,
            'count': self.count,
            'amout': self.amout
        }
        return dic


class StockRealtime(db.Model):
    __tablename__ = 'stock_realtime'
    id = db.Column(db.Integer, primary_key=True)
    stock_id = db.Column(db.Integer, db.ForeignKey('stock_list.id'))
    price = db.Column(db.Float, nullable=False, default=0)
    pre_close = db.Column(db.Float, nullable=False, default=0)
    open = db.Column(db.Float, nullable=False, default=0)
    sell = db.Column(db.Float, nullable=False, default=0)
    buy = db.Column(db.Float, nullable=False, default=0)
    buy1 = db.Column(db.Float, nullable=False, default=0)
    buy1_vol = db.Column(db.Float, nullable=False, default=0)
    buy2 = db.Column(db.Float, nullable=False, default=0)
    buy2_vol = db.Column(db.Float, nullable=False, default=0)
    buy3 = db.Column(db.Float, nullable=False, default=0)
    buy3_vol = db.Column(db.Float, nullable=False, default=0)
    buy4 = db.Column(db.Float, nullable=False, default=0)
    buy4_vol = db.Column(db.Float, nullable=False, default=0)
    buy5 = db.Column(db.Float, nullable=False, default=0)
    buy5_vol = db.Column(db.Float, nullable=False, default=0)
    sell1 = db.Column(db.Float, nullable=False, default=0)
    sell1_vol = db.Column(db.Float, nullable=False, default=0)
    sell2 = db.Column(db.Float, nullable=False, default=0)
    sell2_vol = db.Column(db.Float, nullable=False, default=0)
    sell3 = db.Column(db.Float, nullable=False, default=0)
    sell3_vol = db.Column(db.Float, nullable=False, default=0)
    sell4 = db.Column(db.Float, nullable=False, default=0)
    sell4_vol = db.Column(db.Float, nullable=False, default=0)
    sell5 = db.Column(db.Float, nullable=False, default=0)
    sell5_vol = db.Column(db.Float, nullable=False, default=0)
    # recent_exchange = db.Column(db.String, nullable=False, default=0)
    time = db.Column(db.DateTime, nullable=False, default=0)
    change = db.Column(db.Float, nullable=False, default=0)
    change_pct = db.Column(db.Float, nullable=False, default=0)
    high = db.Column(db.Float, nullable=False, default=0)
    low = db.Column(db.Float, nullable=False, default=0)
    # price_volumn_amount = db.Column(db.Float, nullable=False, default=0)
    volumn = db.Column(db.Float, nullable=False, default=0)
    amount = db.Column(db.Float, nullable=False, default=0)
    turnover_rate = db.Column(db.Float, nullable=False, default=0)
    pe = db.Column(db.Float, nullable=False, default=0)
    pb = db.Column(db.Float, nullable=False, default=0)
    amp = db.Column(db.Float, nullable=False, default=0)
    circ_mv = db.Column(db.Float, nullable=False, default=0)
    total_mv = db.Column(db.Float, nullable=False, default=0)
    top = db.Column(db.Float, nullable=False, default=0)
    bottom = db.Column(db.Float, nullable=False, default=0)
    lb = db.Column(db.Float, nullable=False, default=0)
    price_avg = db.Column(db.Float, nullable=False, default=0)


if __name__ == "__main__":
    pass

    amount = db.Column(db.Integer, default=0, nullable=False)
    amount = db.Column(db.Integer, default=0, nullable=False)
