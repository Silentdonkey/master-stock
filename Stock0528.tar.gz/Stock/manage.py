#! /usr/bin/env python3
from flask_script import Manager
from flask_migrate import Migrate, MigrateCommand
from app import create_app, db
from app.models import *

app = create_app()

manager = Manager(app)
migrate = Migrate(app ,db)
# 为manager绑定数据库迁移命令,关键词'db'
manager.add_command('db', MigrateCommand)

if __name__ == "__main__":
    manager.run()