# stock_flask
An exercise for flask
 - 0626
   - 修正了@main.before_request将对静态文件资源的访问也重定向，造成网页js脚本失效的问题
   - 在初始化操作结束时主动执行commit，防止出现某个错误

 - 0623
   - 整合了胡写的股票搜索功能
   - 将访问/init实现的数据初始化功能放到了main.before_app_first_request路由中，以在app启动后第一次访问时处理数据初始化工作，
     后台实时数据更新也在此处同时启动；
   - 修正了数据初始化的若干bug（主要是main.before_request处理逻辑上的bug，以及在没有初始数据时无法更新数据的bug）

 - 0621
   - 设置main.before_app_first_request，在第一次访问时，创建二级子进程用来持续更新数据库数据
   - 修改market.html实时数据的更新方式，现在直接从腾讯的接口获取数据并在前端解析
   - 因为某些bug我现在无法修改index.js.....任何改动都不会在页面生效，我不太想处理轮播图的跳转了...

 - 0620
   - 修改了market，account，crawler等蓝图的路由前缀，相应修改了js文件和html文件的引用。添加了main蓝图
   - 登录验证移动到main蓝图下，在main.views中做了若干跳转，使得访问'/'时自动跳转到market主页

 - 0619
   - 将曹的网页模板与其他静态素材合并进来
   - 为market蓝图添加登陆验证，以测试登陆验证功能（以后可能会将登陆验证移到account蓝图下，market下的登陆前/后页面要进行定制渲染，而不是统一验证跳转）

